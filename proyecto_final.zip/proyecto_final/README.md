# Proyecto Spring Boot API Productos

## Endpoints principales

- GET /productos
- POST /productos
- GET /productos/{nombre}
- PUT /productos/{id}
- DELETE /productos/{id}

Base de datos H2, Swagger, Docker-ready.
