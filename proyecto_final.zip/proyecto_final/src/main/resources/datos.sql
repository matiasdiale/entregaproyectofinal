INSERT INTO producto (nombre, precio, stock) VALUES ('Coca-Cola', 150.0, 100);
INSERT INTO producto (nombre, precio, stock) VALUES ('Pepsi', 140.0, 50);
